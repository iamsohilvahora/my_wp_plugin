<?php

if (!defined('ABSPATH')) exit;


// Silence is golden
